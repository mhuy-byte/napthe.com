import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';
export const metadata: Metadata = {title:'NEXUS.GG — Game Store',description:'Cửa hàng gói nạp game, vật phẩm số và dịch vụ game.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="vi"><body><Header/>{children}<footer className="footer"><div className="wrap footer-inner"><div className="brand"><span className="brand-icon">N</span><span>NEXUS<span className="brand-accent">.GG</span><small>GAME STORE</small></span></div><p>© 2026 NEXUS.GG. Cửa hàng demo — kiểm tra điều khoản nhà phát hành trước khi giao dịch.</p><a href="mailto:support@example.com">Liên hệ hỗ trợ</a></div></footer></body></html>}
