import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase-server';
export async function GET(){const sb=createClient();const {data:{user}}=await sb.auth.getUser();if(!user)return NextResponse.json({success:false,error:'Unauthorized'},{status:401});const {data,error}=await sb.from('orders').select('id,product_title,game,price,status,created_at').eq('user_id',user.id).order('created_at',{ascending:false});if(error)return NextResponse.json({success:false,error:'Could not load orders'},{status:500});return NextResponse.json({success:true,data});}
