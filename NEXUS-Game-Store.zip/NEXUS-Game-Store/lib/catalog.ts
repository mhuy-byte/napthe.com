export type Product = { id: string; title: string; game: string; category: 'Nạp game'|'Vật phẩm'|'Dịch vụ'; price: number; description: string; badge?: string; icon: string };
export const demoProducts: Product[] = [
 {id:'ml-86',title:'86 + 8 Kim Cương',game:'Mobile Legends',category:'Nạp game',price:49000,description:'Gói kim cương dành cho tài khoản Mobile Legends.',badge:'Phổ biến',icon:'💎'},
 {id:'ml-172',title:'172 + 17 Kim Cương',game:'Mobile Legends',category:'Nạp game',price:95000,description:'Nạp nhanh, kiểm tra UID trước khi đặt.',icon:'💎'},
 {id:'ff-100',title:'100 + 10 Kim Cương',game:'Free Fire',category:'Nạp game',price:25000,description:'Gói kim cương Free Fire.',badge:'Giá tốt',icon:'🔥'},
 {id:'ff-530',title:'530 + 53 Kim Cương',game:'Free Fire',category:'Nạp game',price:119000,description:'Gói dành cho người chơi Free Fire.',icon:'🔥'},
 {id:'pubg-60',title:'60 UC',game:'PUBG Mobile',category:'Nạp game',price:29000,description:'UC cho PUBG Mobile.',icon:'🎯'},
 {id:'pubg-325',title:'325 UC',game:'PUBG Mobile',category:'Nạp game',price:139000,description:'Gói UC phổ biến.',badge:'Bán chạy',icon:'🎯'},
 {id:'robux-400',title:'400 Robux',game:'Roblox',category:'Vật phẩm',price:125000,description:'Sản phẩm số; phương thức giao nhận cần xác nhận.',icon:'🧱'},
 {id:'lol-coach',title:'Tư vấn chiến thuật 30 phút',game:'Liên Minh Huyền Thoại',category:'Dịch vụ',price:79000,description:'Buổi tư vấn cải thiện lối chơi, không yêu cầu mật khẩu tài khoản.',icon:'⚔️'},
 {id:'genshin-welkin',title:'Phước Lành Nguyệt Ca',game:'Genshin Impact',category:'Nạp game',price:115000,description:'Gói hỗ trợ tài khoản Genshin Impact.',icon:'🌙'},
 {id:'valorant-points',title:'475 VP',game:'VALORANT',category:'Nạp game',price:119000,description:'Điểm VALORANT theo khu vực hỗ trợ.',icon:'🎮'},
 {id:'steam-wallet',title:'Steam Wallet 100.000đ',game:'Steam',category:'Vật phẩm',price:105000,description:'Mã ví điện tử game; kiểm tra khu vực trước khi mua.',icon:'🕹️'},
 {id:'game-support',title:'Hỗ trợ cài đặt game',game:'Dịch vụ game',category:'Dịch vụ',price:50000,description:'Hướng dẫn cài đặt và tối ưu cơ bản từ xa.',icon:'🛠️'}
];
export const formatVND = (n:number) => new Intl.NumberFormat('vi-VN',{style:'currency',currency:'VND',maximumFractionDigits:0}).format(n);
