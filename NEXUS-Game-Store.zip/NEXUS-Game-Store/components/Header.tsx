'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase-browser';
import { Gamepad2, Menu, X, UserRound, LogOut } from 'lucide-react';
export default function Header(){
 const [email,setEmail]=useState<string|null>(null); const [open,setOpen]=useState(false);
 useEffect(()=>{ const supabase=createClient(); supabase.auth.getUser().then(({data})=>setEmail(data.user?.email??null)); const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setEmail(s?.user?.email??null)); return ()=>subscription.unsubscribe();},[]);
 const logout=async()=>{await createClient().auth.signOut(); location.href='/';};
 return <header className="site-header"><div className="nav wrap"><Link href="/" className="brand"><span className="brand-icon"><Gamepad2 size={23}/></span><span>NEXUS<span className="brand-accent">.GG</span><small>GAME STORE</small></span></Link><button className="mobile-toggle" onClick={()=>setOpen(!open)} aria-label="Mở menu">{open?<X/>:<Menu/>}</button><nav className={open?'nav-links open':'nav-links'}><Link href="/#store" onClick={()=>setOpen(false)}>Cửa hàng</Link><Link href="/#how" onClick={()=>setOpen(false)}>Hướng dẫn</Link>{email?<><Link href="/account"><UserRound size={16}/> Tài khoản</Link><button className="nav-logout" onClick={logout}><LogOut size={15}/> Đăng xuất</button></>:<><Link href="/login">Đăng nhập</Link><Link className="btn btn-small" href="/register">Tạo tài khoản</Link></>}</nav></div></header>
}
