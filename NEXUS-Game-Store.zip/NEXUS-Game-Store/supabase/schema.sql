-- Run this in Supabase SQL Editor. Supabase Auth handles passwords; never store plaintext passwords.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  phone text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id text primary key,
  title text not null,
  game text not null,
  category text not null check (category in ('Nạp game','Vật phẩm','Dịch vụ')),
  price integer not null check (price >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.products(id,title,game,category,price) values
('ml-86','86 + 8 Kim Cương','Mobile Legends','Nạp game',49000),
('ml-172','172 + 17 Kim Cương','Mobile Legends','Nạp game',95000),
('ff-100','100 + 10 Kim Cương','Free Fire','Nạp game',25000),
('ff-530','530 + 53 Kim Cương','Free Fire','Nạp game',119000),
('pubg-60','60 UC','PUBG Mobile','Nạp game',29000),
('pubg-325','325 UC','PUBG Mobile','Nạp game',139000),
('robux-400','400 Robux','Roblox','Vật phẩm',125000),
('lol-coach','Tư vấn chiến thuật 30 phút','Liên Minh Huyền Thoại','Dịch vụ',79000),
('genshin-welkin','Phước Lành Nguyệt Ca','Genshin Impact','Nạp game',115000),
('valorant-points','475 VP','VALORANT','Nạp game',119000),
('steam-wallet','Steam Wallet 100.000đ','Steam','Vật phẩm',105000),
('game-support','Hỗ trợ cài đặt game','Dịch vụ game','Dịch vụ',50000)
on conflict (id) do update set title=excluded.title,game=excluded.game,category=excluded.category,price=excluded.price;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null references public.products(id),
  product_title text not null,
  game text not null,
  price integer not null check (price >= 0),
  player_uid text,
  server_id text,
  phone text,
  status text not null default 'pending' check (status in ('pending','processing','completed','cancelled')),
  created_at timestamptz not null default now()
);
create index if not exists orders_user_created_idx on public.orders(user_id, created_at desc);
create index if not exists orders_status_idx on public.orders(status);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

drop policy if exists "profiles select own" on public.profiles;
create policy "profiles select own" on public.profiles for select to authenticated using (id = (select auth.uid()));
drop policy if exists "profiles update own safe fields" on public.profiles;
create policy "profiles update own safe fields" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()) and role = 'customer');
drop policy if exists "products public read active" on public.products;
create policy "products public read active" on public.products for select to anon, authenticated using (active = true);
drop policy if exists "orders select own or admin" on public.orders;
create policy "orders select own or admin" on public.orders for select to authenticated using (user_id = (select auth.uid()) or exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='admin'));
-- Deliberately no direct INSERT policy on orders. New orders must go through create_order(),
-- which takes the authenticated user's ID from auth.uid() and reads price from products.
drop policy if exists "orders insert own pending" on public.orders;
drop policy if exists "admin update orders" on public.orders;
create policy "admin update orders" on public.orders for update to authenticated using (exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='admin')) with check (exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='admin'));

create or replace function public.create_order(p_product_id text, p_player_uid text default null, p_server_id text default null, p_phone text default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_user_id uuid; v_product public.products%rowtype; v_order_id uuid;
begin
  v_user_id := auth.uid();
  if v_user_id is null then raise exception 'Authentication required'; end if;
  select * into v_product from public.products where id=p_product_id and active=true;
  if not found then raise exception 'Product is unavailable'; end if;
  insert into public.orders(user_id,product_id,product_title,game,price,player_uid,server_id,phone,status)
  values(v_user_id,v_product.id,v_product.title,v_product.game,v_product.price,left(p_player_uid,100),left(p_server_id,80),left(p_phone,25),'pending')
  returning id into v_order_id;
  return v_order_id;
end;
$$;
revoke all on function public.create_order(text,text,text,text) from public;
grant execute on function public.create_order(text,text,text,text) to authenticated;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name, phone)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name',''), coalesce(new.raw_user_meta_data ->> 'phone',''))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- After registering your own account, promote it manually in SQL Editor:
-- update public.profiles set role='admin' where id=(select id from auth.users where email='YOUR_EMAIL_HERE');
