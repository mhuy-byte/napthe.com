# NEXUS.GG — Game Store

A dark-premium Next.js storefront starter for game top-ups, digital items, and gaming services. Uses GitHub + Vercel + Supabase.

## Included
- Responsive storefront, category tabs, search, product cards, cart and checkout modal
- Supabase email/password registration and login
- Customer order history
- Admin-only order listing and protected API endpoints
- Supabase schema with RLS policies and profile creation trigger
- Environment variable example and security checklist

## 1. Supabase setup
1. Create/open your Supabase project.
2. Open **SQL Editor**, paste `supabase/schema.sql`, and run it.
3. In **Project Settings → API** (or API Keys), copy the Project URL and publishable/anon key.
4. In Authentication settings, configure the site URL and redirect URLs for localhost and your Vercel domain.
5. Register your own account through the website. If email confirmation is enabled, confirm the email.
6. Promote your account to admin in SQL Editor using the commented SQL at the bottom of `schema.sql`, replacing `YOUR_EMAIL_HERE` with your exact account email.

## 2. Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env.local`.
3. Fill in `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` with the real values from your project. Do not paste placeholder values.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open `http://localhost:3000`.

## 3. Deploy with GitHub + Vercel
1. Create a GitHub repository and upload all files in this project.
2. In Vercel, import that repository.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` under Project → Settings → Environment Variables for Production and Preview.
4. Redeploy after changing environment variables.
5. Add the deployed Vercel URL to Supabase Auth's allowed redirect URLs.

## 4. Product/order behavior
The storefront catalog in `lib/catalog.ts` is demo display data; `supabase/schema.sql` also seeds the matching `products` table. Checkout calls the `create_order()` database function, which derives the user from `auth.uid()` and reads the authoritative price from `products`. There is no direct client INSERT policy on `orders`. Keep the database catalog synchronized with displayed products. Payment is not integrated in this starter; do not represent an order as paid until a verified payment webhook confirms it.

## 5. Security checklist
- Keep the Supabase service-role key out of the browser and out of GitHub. This project does not need it for normal user flows.
- Only expose the publishable/anon key as `NEXT_PUBLIC_SUPABASE_ANON_KEY`; RLS must remain enabled.
- Do not store user passwords in `public.users` or any application table. Supabase Auth manages password hashes.
- Promote admin accounts manually from SQL Editor. Never expose an admin-registration form.
- Test that user A cannot read user B's orders; test that a customer cannot update order status; test that a non-admin receives 403 from `/api/admin/orders`.
- Add rate limiting/CAPTCHA to signup and order creation before public launch.
- Add payment provider integration with server-side signature verification before accepting payments.
- Verify game publisher terms, delivery rules, refunds, privacy policy and support contact before real sales.

## Routes
- `/` — storefront
- `/register` — create account
- `/login` — sign in
- `/account` — own order history
- `/admin` — admin-only order listing
- `GET /api/orders` — own order history
- `GET/PATCH /api/admin/orders` — admin-only list/update status

## Notes
This is a working starter scaffold, not a claim that payment, automatic game delivery, wallet top-ups, or customer support integrations are already live. Those require real provider credentials and end-to-end tests.
